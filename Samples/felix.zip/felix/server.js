const Hapi = require('hapi');
const Guid = require('guid');

const server = new Hapi.Server();
server.connection({
  // host: '10.77.82.245',
  host: '192.168.43.95',
  port: 8989
});

//Add route
server.route([
  {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
    method: 'GET',
    path: '/rest/userservice/user/1',
    handler: function (request, reply) {
      return reply({ 'id': 1, 'name': 'jp' });
    }
  },
  {
    method: 'GET',
    path: '/rest/userservice/user/2',
    handler: function (request, reply) {
      return reply({ 'id': 2, 'name': 'jp' });
    }
  },
    {
    method: 'GET',
    path: '/rest/userservice/user/3',
    handler: function (request, reply) {
      return reply({ });
    }
  },
  {
    method: 'POST',
    path: '/rest/userservice/user/devicetoken',
    handler: function (request, reply) {
      console.log(request.payload);
      return reply({ status: 200 });
    } 
  },
  {
    method: 'GET',
    path: '/rest/realtime/alarms/user/1',
    handler: function (request, reply) {
      var guid = Guid.create();
      return reply({entity:[
        { 'id': Guid.raw(), 'siteId': 1, 'alarmName':'High Temp -01','alarmLevel':0, 'alarmDescription': '超市G4电流', 'subsystemId':0, 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'siteId': 1, 'alarmName': 'High Temp -01', 'alarmLevel':1,'alarmDescription': '大商业模块', 'subsystemId':1, 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'siteId': 1, 'alarmName': 'High Temp -01', 'alarmLevel':2,'alarmDescription': '低水位报警', 'subsystemId':0, 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'siteId': 1, 'alarmName': 'High Temp -01', 'alarmLevel':0, 'alarmDescription': '门已坏，打不开', 'subsystemId':'暖通空调', 'alarmDateTime':'2016-08-11 14:12:09' }
         ,  { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':1,'alarmDescription': '超市G4电流', 'subsystemId':'暖通空调', 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':2,'alarmDescription': '大商业模块', 'subsystemId':'变配电', 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':0,'alarmDescription': '低水位报警', 'subsystemId':'暖通空调', 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':0,'alarmDescription': '门已坏，打不开', 'subsystemId':'暖通空调', 'alarmDateTime':'2016-08-11 14:12:09' }
,
      { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':0,'alarmDescription': '超市G4电流', 'subsystemId':'暖通空调', 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':0,'alarmDescription': '大商业模块', 'subsystemId':'变配电', 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':0,'alarmDescription': '低水位报警', 'subsystemId':'暖通空调', 'alarmDateTime':'2016-08-11 14:12:09' },
        { 'id': Guid.raw(), 'alarmName': 'High Temp -01', 'alarmLevel':0,'alarmDescription': '门已坏，打不开', 'subsystemId':'暖通空调', 'alarmDateTime':'2016-08-11 14:12:09' }

      ]});
    }
  }
]);

//Start the server
server.start( (err) => {
  if(err){
    throw err;
  }
  console.log(`server running at ${server.info.uri}`);
})